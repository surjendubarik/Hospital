package com.example.surjendubarik.doctors;

import android.app.Fragment;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.security.cert.Extension;

public class activity3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_activity3);

    }
    public void click (View view){
        if (view.getId() == R.id.bhubaneswar) {
            Intent intent = new Intent(activity3.this, activity4.class);
            startActivity(intent);
        } else if (view.getId() == R.id.cuttack) {
            Intent intent = new Intent(activity3.this, ctc_hospital.class);
            startActivity(intent);
        } else if (view.getId() == R.id.rourkela) {
            Intent intent = new Intent(activity3.this, rour_hospital.class);
            startActivity(intent);
        }
    }
}



