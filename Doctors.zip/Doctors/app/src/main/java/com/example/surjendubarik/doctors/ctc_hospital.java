package com.example.surjendubarik.doctors;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

public class ctc_hospital extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ctc_hospital);

    }
    public void onClick (View view){
        if (view.getId() == R.id.ashwini) {
            Intent intent = new Intent(ctc_hospital.this, ashwini.class);
            startActivity(intent);
        } else if (view.getId() == R.id.scb) {
            Intent intent = new Intent(ctc_hospital.this, scb.class);
            startActivity(intent);
        } else if (view.getId() == R.id.pqr) {
            Intent intent = new Intent(ctc_hospital.this, pqrweb.class);
            startActivity(intent);
        } else if (view.getId() == R.id.rdx) {
            Toast.makeText(getApplicationContext(), "This Hospital Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }


