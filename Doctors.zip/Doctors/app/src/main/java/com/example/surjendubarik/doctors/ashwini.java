package com.example.surjendubarik.doctors;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

public class ashwini extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ashwini);
        WebView ashwini = (WebView) findViewById(R.id.ashwini);
        ashwini.loadUrl("file:///android_asset/ashwini.html");
        ashwini.getSettings().setJavaScriptEnabled(true);
    }
}



