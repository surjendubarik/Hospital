package com.example.surjendubarik.doctors;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class pqrweb extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pqrweb);
        WebView pqrweb = (WebView) findViewById(R.id.pqrweb);
        pqrweb.loadUrl("file:///android_asset/pqr.html");
        pqrweb.getSettings().setJavaScriptEnabled(true);
    }
}
