package com.example.surjendubarik.doctors;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;



import android.widget.Button;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
            public void onClick(View view) {
                if(view.getId()==R.id.diabetes){
                Intent intent = new Intent(MainActivity.this,activity3.class);
                startActivity(intent);
            }
            else if(view.getId()==R.id.heartdisease){
                    Intent intent = new Intent(MainActivity.this,activity3.class);
                    startActivity(intent);
                }
                else if(view.getId()==R.id.asthma){
                    Intent intent = new Intent(MainActivity.this,activity3.class);
                    startActivity(intent);
                }
                else if(view.getId()==R.id.kidney){
                    Intent intent = new Intent(MainActivity.this,activity3.class);
                    startActivity(intent);
                }
                else if(view.getId()==R.id.cancer){
                    Intent intent = new Intent(MainActivity.this,activity3.class);
                    startActivity(intent);
                }

            }
}
