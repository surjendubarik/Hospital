package com.example.surjendubarik.doctors;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;

public class activity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

    }
    public void onClick (View view){
        if (view.getId() == R.id.abc) {
            Intent intent = new Intent(activity4.this, abcweb.class);
            startActivity(intent);
        } else if (view.getId() == R.id.aiims) {
            Intent intent = new Intent(activity4.this, aiims.class);
            startActivity(intent);
        } else if (view.getId() == R.id.capital) {
                Intent intent = new Intent(activity4.this, capital.class);
                startActivity(intent);
        }
    }
}


