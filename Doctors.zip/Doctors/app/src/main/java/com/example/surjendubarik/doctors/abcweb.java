package com.example.surjendubarik.doctors;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class abcweb extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abcweb);
        WebView abcweb = (WebView) findViewById(R.id.abcweb);
        abcweb.loadUrl("file:///android_asset/abc.html");
        abcweb.getSettings().setJavaScriptEnabled(true);

    }
}
