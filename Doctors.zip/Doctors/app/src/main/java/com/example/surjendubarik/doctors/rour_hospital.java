package com.example.surjendubarik.doctors;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

public class rour_hospital extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rour_hospital);

    }
    public void onClick (View view){
        if (view.getId() == R.id.jayrour) {
            Intent intent = new Intent(rour_hospital.this, jayrour.class);
            startActivity(intent);
        }
    }
}


