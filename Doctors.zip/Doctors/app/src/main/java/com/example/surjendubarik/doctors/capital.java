package com.example.surjendubarik.doctors;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class capital extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capital);
        WebView capital = (WebView) findViewById(R.id.capital);
        capital.loadUrl("file:///android_asset/Capital.html");
        capital.getSettings().setJavaScriptEnabled(true);
    }
}

